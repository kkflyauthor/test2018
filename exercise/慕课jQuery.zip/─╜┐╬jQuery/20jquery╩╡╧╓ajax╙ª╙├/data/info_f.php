<?php
	echo json_encode(array("name"=>"土豪"，"say"=>"咱们交个朋友吧！"));
?>